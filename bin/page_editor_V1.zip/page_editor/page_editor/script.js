chrome.action.onClicked.addListener((tab) => {
  if (tab.id) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: function () {
         if (document.querySelector("html").contentEditable == "true") {
            document.querySelector("html").contentEditable = false;
            chrome.runtime.sendMessage("");
         }else{
            document.querySelector("html").contentEditable = true;
            chrome.runtime.sendMessage("s");
         }
      }
    });
  }
});
chrome.runtime.onMessage.addListener(function (data) {
    chrome.action.setIcon({path: {24: chrome.runtime.getURL(data + "24.png"), 32: chrome.runtime.getURL(data + "32.png"), 64: chrome.runtime.getURL(data + "64.png")}});
});
chrome.tabs.onHighlighted.addListener((tab) => {
  chrome.scripting.executeScript({
     target: { tabId: tab.tabIds[0] },
     func: function () {
      if (document.querySelector("html").contentEditable == "true") {
        chrome.runtime.sendMessage("s");
      }else{
        chrome.runtime.sendMessage("");
      }
    }
  });
});